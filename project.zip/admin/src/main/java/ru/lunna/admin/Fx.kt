package ru.lunna.admin

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator

/** Фон: медленно падающие мерцающие огоньки (снег). */
class ParticleView(ctx: Context) : View(ctx) {
    private class P(
        var x: Float, var y: Float, val r: Float, val v: Float,
        val d: Float, val a: Float, val ph: Float, val tw: Float
    )

    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random()
    private val dens = ctx.resources.displayMetrics.density
    private var last = 0L

    private fun make(w: Int, h: Int, anywhere: Boolean) = P(
        rnd.nextFloat() * w,
        if (anywhere) rnd.nextFloat() * h else -20f,
        (1f + rnd.nextFloat() * 2.8f) * dens,
        (14f + rnd.nextFloat() * 40f) * dens,
        (rnd.nextFloat() - 0.5f) * 24f * dens,
        0.35f + rnd.nextFloat() * 0.55f,
        rnd.nextFloat() * 6.28f,
        0.8f + rnd.nextFloat() * 1.6f
    )

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        ps.clear()
        if (w > 0 && h > 0) repeat(60) { ps.add(make(w, h, true)) }
    }

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        val t = now / 1000f
        for (i in ps.indices) {
            val p = ps[i]
            p.y += p.v * dt
            p.x += p.d * dt
            if (p.y > height + 20 || p.x < -20 || p.x > width + 20) ps[i] = make(width, height, false)
            val tw = 0.65f + 0.35f * kotlin.math.sin(t * p.tw + p.ph)
            paint.color = Color.argb((255 * p.a * tw).toInt().coerceIn(0, 255), 214, 190, 255)
            c.drawCircle(p.x, p.y, p.r, paint)
        }
        postInvalidateOnAnimation()
    }
}

/** Лёгкое нажатие: кнопка чуть уменьшается. Клик при этом работает как обычно. */
@SuppressLint("ClickableViewAccessibility")
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}

/** Плавное появление снизу с задержкой. */
fun View.enter(delayMs: Long, dy: Float = 40f) {
    alpha = 0f
    translationY = dy
    animate().alpha(1f).translationY(0f).setStartDelay(delayMs).setDuration(450)
        .setInterpolator(DecelerateInterpolator()).start()
}

/** Бесконечное плавное покачивание вверх-вниз. */
fun View.floatLoop(amp: Float, ms: Long = 2800): ObjectAnimator =
    ObjectAnimator.ofFloat(this, View.TRANSLATION_Y, -amp, amp).apply {
        duration = ms
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        start()
    }

/** Бесконечное «дыхание» (лёгкое увеличение). */
fun View.pulse(): ObjectAnimator =
    ObjectAnimator.ofPropertyValuesHolder(
        this,
        android.animation.PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.035f),
        android.animation.PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.035f)
    ).apply {
        duration = 900
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        start()
    }
