package ru.lunna.admin

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

class AdminActivity : Activity() {

    companion object {
        const val OWNER = "az3005484-afk"
        const val REPO = "lunna-launcher"
        const val BRANCH = "main"
        const val GAME_PACKAGE = "com.kranin"
        const val VIOLET = 0xFF7B2CFF.toInt()
        const val BG = 0xFF0B0614.toInt()
        const val REQ_TREE = 1
        const val REQ_APK = 2
        const val MAX_ASSET = 2_000_000_000L
    }

    private val prefs by lazy { getSharedPreferences("admin", MODE_PRIVATE) }

    private lateinit var logView: TextView
    private lateinit var bar: ProgressBar
    private lateinit var treeLabel: TextView
    private lateinit var activityField: EditText
    private lateinit var noticeTitle: EditText
    private lateinit var noticeText: EditText

    @Volatile
    private var working = false

    private var token = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(block: () -> Unit) = runOnUiThread { block() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (prefs.getString("hash", null) == null) showSetup() else showLogin()
    }

    // ---------- UI helpers ----------

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(BG)
        setPadding(dp(24), dp(24), dp(24), dp(24))
    }

    private fun text(t: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun edit(hint: String, password: Boolean = false, multiline: Boolean = false) =
        EditText(this).apply {
            this.hint = hint
            setHintTextColor(0xFF8F7FB8.toInt())
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(0xFF1B1130.toInt())
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT
            }
        }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(VIOLET)
            cornerRadius = dp(12).toFloat()
        }
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.addGap(v: View, top: Int = 8) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(top)
        addView(v, lp)
    }

    private fun logo(root: LinearLayout) {
        val img = ImageView(this).apply { setImageResource(R.drawable.logo) }
        val lp = LinearLayout.LayoutParams(dp(120), dp(120))
        lp.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(img, lp)
    }

    private fun hash(salt: String, pass: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pass).toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ---------- экраны входа ----------

    private fun showSetup() {
        val root = page()
        logo(root)
        root.addView(text("Первая настройка", 22f))
        root.addView(text("Придумай логин и пароль для входа в админку и вставь токен GitHub."))
        val l = edit("Логин")
        val p = edit("Пароль", password = true)
        val t = edit("Токен GitHub", password = true)
        root.addGap(l); root.addGap(p); root.addGap(t)
        root.addGap(button("Сохранить") {
            if (l.text.isBlank() || p.text.length < 4 || t.text.isBlank()) {
                toast("Заполни всё, пароль от 4 символов")
            } else {
                val salt = System.nanoTime().toString()
                prefs.edit()
                    .putString("login", l.text.toString().trim())
                    .putString("salt", salt)
                    .putString("hash", hash(salt, p.text.toString()))
                    .putString("token", t.text.toString().trim())
                    .apply()
                token = t.text.toString().trim()
                showPanel()
            }
        }, 20)
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    private fun showLogin() {
        val root = page()
        logo(root)
        root.addView(text("Вход в админку", 22f))
        val l = edit("Логин")
        val p = edit("Пароль", password = true)
        root.addGap(l); root.addGap(p)
        root.addGap(button("Войти") {
            val ok = l.text.toString().trim() == prefs.getString("login", "") &&
                hash(prefs.getString("salt", "")!!, p.text.toString()) == prefs.getString("hash", "")
            if (ok) {
                token = prefs.getString("token", "") ?: ""
                showPanel()
            } else toast("Неверный логин или пароль")
        }, 20)
        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    // ---------- панель ----------

    private fun showPanel() {
        val root = page()
        logo(root)
        root.addView(text("Панель управления", 22f))

        root.addView(text("Кеш", 17f, 0xFFC9B8FF.toInt()))
        treeLabel = text(
            if (prefs.getString("tree", null) == null) "Папка не выбрана"
            else "Папка выбрана", 14f, 0xFF8F7FB8.toInt()
        )
        root.addView(treeLabel)
        root.addGap(button("Выбрать папку с кешем") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),
                REQ_TREE
            )
        })
        root.addGap(button("Опубликовать обновление кеша") { task("Публикация кеша") { publishCache() } })

        root.addView(text("Клиент (APK игры)", 17f, 0xFFC9B8FF.toInt()).also {
            it.setPadding(0, dp(18), 0, dp(6))
        })
        activityField = edit("Имя Activity игры (например com.kranin.MainActivity)")
        activityField.setText(prefs.getString("activity", ""))
        root.addGap(activityField)
        root.addGap(button("Сохранить Activity в манифест") { task("Activity") { saveActivity() } })
        root.addGap(button("Загрузить новый APK игры") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),
                REQ_APK
            )
        })

        root.addView(text("Уведомление всем", 17f, 0xFFC9B8FF.toInt()).also {
            it.setPadding(0, dp(18), 0, dp(6))
        })
        noticeTitle = edit("Заголовок")
        noticeText = edit("Текст уведомления", multiline = true)
        root.addGap(noticeTitle)
        root.addGap(noticeText)
        root.addGap(button("Отправить уведомление") { task("Уведомление") { sendNotice() } })

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(VIOLET)
        }
        root.addGap(bar, 20)
        logView = text("", 13f, 0xFFC9B8FF.toInt())
        root.addView(logView)

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun log(s: String) = ui { logView.append(s + "\n") }

    private fun setProgress(done: Long, total: Long) {
        if (total <= 0) return
        ui { bar.progress = (done * 100 / total).toInt().coerceIn(0, 100) }
    }

    private fun task(name: String, block: () -> Unit) {
        if (working) {
            toast("Подожди, предыдущая операция ещё идёт")
            return
        }
        working = true
        ui { logView.text = ""; bar.progress = 0 }
        log("▶ $name")
        Thread {
            try {
                block()
            } catch (e: Exception) {
                log("✖ Ошибка: ${e.message}")
            } finally {
                working = false
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_TREE -> {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                prefs.edit().putString("tree", uri.toString()).apply()
                treeLabel.text = "Папка выбрана: " + (DocumentFile.fromTreeUri(this, uri)?.name ?: "")
            }
            REQ_APK -> {
                prefs.edit().putString("activity", activityField.text.toString().trim()).apply()
                task("Загрузка APK") { publishApk(uri) }
            }
        }
    }

    // ---------- GitHub API ----------

    private fun api(method: String, url: String, body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.connectTimeout = 20000
        c.readTimeout = 60000
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private val repoApi get() = "https://api.github.com/repos/$OWNER/$REPO"

    private fun getManifest(): Pair<JSONObject, String?> {
        val (code, text) = api("GET", "$repoApi/contents/manifest.json?ref=$BRANCH")
        if (code == 404) return JSONObject().put("version", 0) to null
        if (code != 200) throw Exception("Манифест: HTTP $code (проверь токен)")
        val j = JSONObject(text)
        val raw = String(Base64.decode(j.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
        return JSONObject(raw) to j.getString("sha")
    }

    private fun putManifest(m: JSONObject, sha: String?) {
        val body = JSONObject()
            .put("message", "update manifest v${m.optInt("version")}")
            .put("content", Base64.encodeToString(m.toString(2).toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
            .put("branch", BRANCH)
        if (sha != null) body.put("sha", sha)
        val (code, text) = api("PUT", "$repoApi/contents/manifest.json", body.toString())
        if (code != 200 && code != 201) throw Exception("Не удалось сохранить манифест: HTTP $code $text")
    }

    private fun ensureRelease(tag: String): Long {
        val (code, text) = api("GET", "$repoApi/releases/tags/$tag")
        if (code == 200) return JSONObject(text).getLong("id")
        val body = JSONObject().put("tag_name", tag).put("name", tag)
            .put("target_commitish", BRANCH).put("body", "auto")
        val (c2, t2) = api("POST", "$repoApi/releases", body.toString())
        if (c2 != 201) throw Exception("Не удалось создать релиз $tag: HTTP $c2 $t2")
        return JSONObject(t2).getLong("id")
    }

    private fun listAssets(releaseId: Long): MutableMap<String, Long> {
        val map = HashMap<String, Long>()
        var page = 1
        while (true) {
            val (code, text) = api("GET", "$repoApi/releases/$releaseId/assets?per_page=100&page=$page")
            if (code != 200) throw Exception("Список файлов релиза: HTTP $code")
            val arr = JSONArray(text)
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                map[o.getString("name")] = o.getLong("id")
            }
            page++
        }
        return map
    }

    private fun deleteAsset(id: Long) {
        val (code, _) = api("DELETE", "$repoApi/releases/assets/$id")
        if (code != 204 && code != 404) throw Exception("Не удалось удалить файл релиза: HTTP $code")
    }

    private fun uploadAsset(releaseId: Long, name: String, size: Long, open: () -> InputStream?, onBytes: (Long) -> Unit) {
        if (size > MAX_ASSET) throw Exception("$name больше 2 ГБ, GitHub не примет")
        val url = "https://uploads.github.com/repos/$OWNER/$REPO/releases/$releaseId/assets?name=" +
            URLEncoder.encode(name, "UTF-8")
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("Content-Type", "application/octet-stream")
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.doOutput = true
        c.setFixedLengthStreamingMode(size)
        try {
            val input = open() ?: throw Exception("Не удалось прочитать $name")
            input.use { ins ->
                c.outputStream.use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        onBytes(n.toLong())
                    }
                }
            }
            val code = c.responseCode
            if (code != 201) {
                val err = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw Exception("Загрузка $name: HTTP $code $err")
            }
        } finally {
            c.disconnect()
        }
    }

    // ---------- операции ----------

    private fun sha256(open: () -> InputStream?, onBytes: (Long) -> Unit = {}): String {
        val md = MessageDigest.getInstance("SHA-256")
        val input = open() ?: throw Exception("Не удалось прочитать файл")
        input.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                onBytes(n.toLong())
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun assetName(path: String): String {
        val h = MessageDigest.getInstance("SHA-1").digest(path.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(8)
        val base = path.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
        return "${h}_$base"
    }

    private fun walk(dir: DocumentFile, prefix: String, out: MutableList<Pair<String, DocumentFile>>) {
        for (f in dir.listFiles()) {
            val n = f.name ?: continue
            if (f.isDirectory) walk(f, "$prefix$n/", out) else out.add((prefix + n) to f)
        }
    }

    private fun publishCache() {
        val treeStr = prefs.getString("tree", null) ?: throw Exception("Сначала выбери папку с кешем")
        val root = DocumentFile.fromTreeUri(this, Uri.parse(treeStr))
            ?: throw Exception("Папка недоступна, выбери её заново")

        log("Читаю манифест…")
        val (m, msha) = getManifest()
        val oldFiles = HashMap<String, JSONObject>()
        val oldArr = m.optJSONObject("cache")?.optJSONArray("files")
        if (oldArr != null) for (i in 0 until oldArr.length()) {
            val o = oldArr.getJSONObject(i)
            oldFiles[o.getString("path")] = o
        }

        log("Сканирую папку…")
        val files = ArrayList<Pair<String, DocumentFile>>()
        walk(root, "", files)
        files.removeAll { it.second.length() == 0L }
        if (files.isEmpty()) throw Exception("В папке нет файлов")

        val totalBytes = files.sumOf { it.second.length() }
        var hashed = 0L
        val shas = HashMap<String, String>()
        for ((path, f) in files) {
            log("Хэш: $path")
            shas[path] = sha256({ contentResolver.openInputStream(f.uri) }) { n ->
                hashed += n
                setProgress(hashed, totalBytes)
            }
        }

        val changed = files.filter { (p, _) -> oldFiles[p]?.optString("sha256") != shas[p] }
        val currentPaths = files.map { it.first }.toSet()
        val removed = oldFiles.keys.filter { it !in currentPaths }

        if (changed.isEmpty() && removed.isEmpty()) {
            log("Изменений нет, публиковать нечего.")
            return
        }
        log("Изменено: ${changed.size}, удалено: ${removed.size}")

        val releaseId = ensureRelease("cache")
        val assets = listAssets(releaseId)

        val upTotal = changed.sumOf { it.second.length() }
        var uploaded = 0L
        ui { bar.progress = 0 }
        for ((path, f) in changed) {
            val name = assetName(path)
            assets[name]?.let { deleteAsset(it) }
            log("Загружаю: $path")
            uploadAsset(releaseId, name, f.length(), { contentResolver.openInputStream(f.uri) }) { n ->
                uploaded += n
                setProgress(uploaded, upTotal)
            }
        }
        for (path in removed) {
            val name = oldFiles[path]?.optString("asset").orEmpty().ifEmpty { assetName(path) }
            assets[name]?.let { deleteAsset(it) }
        }

        val arr = JSONArray()
        for ((path, f) in files) {
            val name = assetName(path)
            arr.put(
                JSONObject()
                    .put("path", path)
                    .put("sha256", shas[path])
                    .put("size", f.length())
                    .put("asset", name)
                    .put("url", "https://github.com/$OWNER/$REPO/releases/download/cache/$name")
            )
        }
        val cache = m.optJSONObject("cache") ?: JSONObject()
        cache.put("files", arr)
        m.put("cache", cache)
        m.put("version", m.optInt("version") + 1)
        putManifest(m, msha)
        log("✔ Готово. Версия ${m.optInt("version")}, обновлено файлов: ${changed.size}")
    }

    private fun publishApk(uri: Uri) {
        val tmp = File(cacheDir, "new_client.apk")
        log("Копирую APK…")
        val md = MessageDigest.getInstance("SHA-256")
        var total = 0L
        val input = contentResolver.openInputStream(uri) ?: throw Exception("Не удалось открыть файл")
        input.use { ins ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    md.update(buf, 0, n)
                    total += n
                }
            }
        }
        val size = total
        val sha = md.digest().joinToString("") { "%02x".format(it) }

        val info = packageManager.getPackageArchiveInfo(tmp.path, 0)
            ?: throw Exception("Это не APK")
        if (info.packageName != GAME_PACKAGE) {
            throw Exception("Пакет ${info.packageName}, а нужен $GAME_PACKAGE")
        }
        val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        log("APK: версия ${info.versionName} (код $code), ${size / 1048576} МБ")

        val (m, msha) = getManifest()
        val oldCode = m.optJSONObject("client")?.optLong("version_code", 0L) ?: 0L
        if (code <= oldCode) {
            log("⚠ Внимание: versionCode $code не выше текущего $oldCode — у игроков обновление не сработает. Подними versionCode в APK.")
        }

        val releaseId = ensureRelease("client")
        listAssets(releaseId)["client.apk"]?.let { deleteAsset(it) }
        log("Загружаю на GitHub…")
        var up = 0L
        uploadAsset(releaseId, "client.apk", size, { tmp.inputStream() }) { n ->
            up += n
            setProgress(up, size)
        }

        val client = JSONObject()
            .put("version_code", code)
            .put("version_name", info.versionName ?: "")
            .put("url", "https://github.com/$OWNER/$REPO/releases/download/client/client.apk")
            .put("sha256", sha)
            .put("size", size)
            .put("activity", prefs.getString("activity", "") ?: "")
        m.put("client", client)
        m.put("version", m.optInt("version") + 1)
        putManifest(m, msha)
        tmp.delete()
        log("✔ Готово. Клиент обновлён, версия манифеста ${m.optInt("version")}")
    }

    private fun saveActivity() {
        val act = activityField.text.toString().trim()
        prefs.edit().putString("activity", act).apply()
        val (m, msha) = getManifest()
        val client = m.optJSONObject("client") ?: JSONObject()
        client.put("activity", act)
        m.put("client", client)
        putManifest(m, msha)
        log("✔ Activity сохранена: $act")
    }

    private fun sendNotice() {
        val title = noticeTitle.text.toString().trim()
        val text = noticeText.text.toString().trim()
        if (text.isEmpty()) throw Exception("Введи текст уведомления")
        val (m, msha) = getManifest()
        m.put(
            "notice",
            JSONObject().put("id", System.currentTimeMillis() / 1000).put("title", title).put("text", text)
        )
        putManifest(m, msha)
        log("✔ Уведомление отправлено. Игроки увидят его при ближайшей проверке (до нескольких минут).")
    }
}
