package ru.lunna.admin

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class AdminActivity : Activity() {

    companion object {
        const val OWNER = "az3005484-afk"
        const val REPO = "lunna-launcher"
        const val BRANCH = "main"
        const val GAME_PACKAGE = "com.mobile.project5875"
        const val DEFAULT_ACTIVITY = "com.blackhub.bronline.launcher.activities.MainActivity"
        const val VIOLET = 0xFF7B2CFF.toInt()
        const val BG = 0xFF0B0614.toInt()
        const val REQ_TREE = 1
        const val REQ_APK = 2
        const val MAX_ASSET = 2_000_000_000L
    }

    private val prefs by lazy { getSharedPreferences("admin", MODE_PRIVATE) }

    private lateinit var bar: ProgressBar
    private lateinit var treeLabel: TextView
    private lateinit var activityField: EditText
    private lateinit var noticeTitle: EditText
    private lateinit var noticeText: EditText
    private lateinit var forumField: EditText
    private lateinit var aboutField: EditText
    private lateinit var updTitleField: EditText
    private lateinit var updTextField: EditText

    @Volatile
    private var working = false

    private var token = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(block: () -> Unit) = runOnUiThread { block() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    // ---------- UI helpers ----------

    private enum class Role { OWNER, DEV }

    private var role = Role.OWNER
    private var devLogin = ""
    private lateinit var logBox: LinearLayout

    private fun rounded(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun screen(content: View): FrameLayout {
        val w = minOf(dp(620), resources.displayMetrics.widthPixels)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        wrap.addView(content, LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT))
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(wrap)
        }
        return FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF22103F.toInt(), BG)
            )
            addView(ParticleView(context))
            addView(scroll)
        }
    }

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(24), dp(18), dp(24))
    }

    private fun text(t: String, size: Float = 15f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun edit(hint: String, password: Boolean = false, multiline: Boolean = false) =
        EditText(this).apply {
            this.hint = hint
            setHintTextColor(0xFF8F7FB8.toInt())
            setTextColor(Color.WHITE)
            background = rounded(0xFF1B1130.toInt(), 12, 2, 0xFF3A2370.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (multiline) {
                minLines = 3
                gravity = Gravity.TOP
            }
        }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 15f
        background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF7B2CFF.toInt(), 0xFFB04CFF.toInt())
        ).apply { cornerRadius = dp(12).toFloat() }
        pressable()
        setOnClickListener { onClick() }
    }

    private fun ghost(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 14f
        background = rounded(0x221B1130, 12, 2, VIOLET)
        pressable()
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.addGap(v: View, top: Int = 8) {
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(top)
        addView(v, lp)
    }

    private fun logo(root: LinearLayout) {
        val img = ImageView(this).apply {
            setImageResource(R.drawable.wordmark)
            adjustViewBounds = true
        }
        val lp = LinearLayout.LayoutParams(dp(240), LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(img, lp)
        img.enter(0, 0f)
        img.postDelayed({ img.floatLoop(dp(4).toFloat()) }, 800)
    }

    private fun card(title: String, vararg views: View): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xCC1B1130.toInt(), 18, 2, 0xFF3A2370.toInt())
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }
        c.addView(TextView(this).apply {
            text = title
            setTextColor(0xFFB89CFF.toInt())
            textSize = 12f
            letterSpacing = 0.12f
        })
        for (v in views) c.addGap(v)
        return c
    }

    private fun hash(salt: String, pass: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pass).toByteArray())
            .joinToString("") { "%02x".format(it) }

    // ---------- экраны входа ----------

    private fun showSetup() {
        val root = page()
        logo(root)
        root.addView(text("Первая настройка владельца", 22f))
        root.addView(text("Придумай логин и пароль для входа и вставь токен GitHub.", 14f, 0xFFC9B8FF.toInt()))
        val l = edit("Логин")
        val p = edit("Пароль", password = true)
        val t = edit("Токен GitHub", password = true)
        root.addGap(l, 14); root.addGap(p); root.addGap(t)
        root.addGap(button("Сохранить") {
            if (l.text.isBlank() || p.text.length < 4 || t.text.isBlank()) {
                toast("Заполни всё, пароль от 4 символов")
            } else {
                val salt = System.nanoTime().toString()
                prefs.edit()
                    .putString("login", l.text.toString().trim())
                    .putString("salt", salt)
                    .putString("hash", hash(salt, p.text.toString()))
                    .putString("token", t.text.toString().trim())
                    .apply()
                token = t.text.toString().trim()
                role = Role.OWNER
                showPanel()
            }
        }, 18)
        root.addGap(ghost("Назад ко входу") { showLogin() }, 10)
        setContentView(screen(root))
    }

    private fun showLogin() {
        token = ""
        val root = page()
        logo(root)
        root.addView(text("Вход в админку", 22f))
        val l = edit("Логин")
        val p = edit("Пароль", password = true)
        root.addGap(l, 14); root.addGap(p)
        root.addGap(button("Войти") { doLogin(l.text.toString().trim(), p.text.toString()) }, 18)
        if (prefs.getString("hash", null) == null) {
            root.addGap(ghost("Первая настройка владельца") { showSetup() }, 10)
        }
        setContentView(screen(root))
    }

    private fun doLogin(login: String, pass: String) {
        if (login.isEmpty() || pass.isEmpty()) {
            toast("Введи логин и пароль")
            return
        }
        val ownerLogin = prefs.getString("login", null)
        if (ownerLogin != null && login == ownerLogin) {
            val ok = hash(prefs.getString("salt", "")!!, pass) == prefs.getString("hash", "")
            if (ok) {
                role = Role.OWNER
                token = prefs.getString("token", "") ?: ""
                showPanel()
            } else toast("Неверный пароль")
            return
        }
        if (working) return
        working = true
        toast("Проверяю…")
        Thread {
            try {
                val devs = fetchDevs().optJSONArray("devs") ?: JSONArray()
                var tok: String? = null
                for (i in 0 until devs.length()) {
                    val e = devs.getJSONObject(i)
                    if (e.getString("login").equals(login, true)) {
                        tok = decryptToken(pass, e)
                        break
                    }
                }
                val t = tok
                if (t == null) {
                    ui { toast("Неверный логин или пароль") }
                } else {
                    ui {
                        role = Role.DEV
                        devLogin = login
                        token = t
                        showPanel()
                    }
                }
            } catch (e: Exception) {
                ui { toast("Нет связи с GitHub: ${e.message}") }
            } finally {
                working = false
            }
        }.start()
    }

    // ---------- панель ----------

    private fun showPanel() {
        val root = page()
        logo(root)

        val chip = TextView(this).apply {
            text = if (role == Role.OWNER) "ВЛАДЕЛЕЦ" else "РАЗРАБОТЧИК · $devLogin"
            setTextColor(Color.WHITE)
            textSize = 12f
            letterSpacing = 0.1f
            setPadding(dp(14), dp(5), dp(14), dp(5))
            background = rounded(if (role == Role.OWNER) 0xFF7B2CFF.toInt() else 0xFF2C7BFF.toInt(), 20)
        }
        val chipLp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        chipLp.gravity = Gravity.CENTER_HORIZONTAL
        chipLp.topMargin = dp(6)
        root.addView(chip, chipLp)

        var idx = 0
        fun put(c: View) {
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(14)
            root.addView(c, lp)
            c.enter(150L + 110L * idx)
            idx++
        }

        if (role == Role.OWNER) {
            treeLabel = text(
                if (prefs.getString("tree", null) == null) "Папка не выбрана" else "Папка выбрана",
                14f, 0xFF8F7FB8.toInt()
            )
            put(card(
                "📦  КЕШ ИГРЫ",
                treeLabel,
                button("Выбрать папку с кешем") {
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),
                        REQ_TREE
                    )
                },
                button("Опубликовать обновление кеша") { task("Публикация кеша") { publishCache() } }
            ))
        }

        activityField = edit("Имя Activity игры")
        activityField.setText(prefs.getString("activity", "")?.ifEmpty { DEFAULT_ACTIVITY } ?: DEFAULT_ACTIVITY)
        put(card(
            "🎮  КЛИЕНТ (APK ИГРЫ)",
            activityField,
            ghost("Сохранить Activity в манифест") { task("Activity") { saveActivity() } },
            button("Загрузить новый APK игры") {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"),
                    REQ_APK
                )
            }
        ))

        forumField = edit("Ссылка кнопки «Форум»")
        aboutField = edit("Ссылка кнопки «О нас» (Telegram)")
        updTitleField = edit("Заголовок блока «Последние обновления»")
        updTextField = edit("Текст обновлений", multiline = true)
        put(card(
            "🎨  ОФОРМЛЕНИЕ ЛАУНЧЕРА",
            forumField, aboutField, updTitleField, updTextField,
            button("Сохранить оформление") { task("Оформление") { saveInfo() } }
        ))

        noticeTitle = edit("Заголовок")
        noticeText = edit("Текст уведомления", multiline = true)
        put(card(
            "🔔  УВЕДОМЛЕНИЕ ВСЕМ",
            noticeTitle, noticeText,
            button("Отправить уведомление") { task("Уведомление") { sendNotice() } }
        ))

        if (role == Role.OWNER) {
            put(card(
                "👥  РАЗРАБОТЧИКИ",
                text("Могут всё, кроме обновления кеша.", 13f, 0xFF8F7FB8.toInt()),
                button("Добавить разработчика") { showAddDev() },
                ghost("Список / удалить") { task("Список разработчиков") { showDevList() } }
            ))
        }

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(VIOLET)
        }
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        put(card("📜  ЖУРНАЛ", bar, logBox))

        val out = ghost("Выйти") { showLogin() }
        put(out)

        setContentView(screen(root))
        Thread { try { loadInfo() } catch (e: Exception) { } }.start()
    }

    private fun showAddDev() {
        val l = edit("Логин разработчика")
        val p = edit("Пароль (от 8 символов)", password = true)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
        }
        box.addGap(l)
        box.addGap(p)
        AlertDialog.Builder(this)
            .setTitle("Новый разработчик")
            .setView(box)
            .setPositiveButton("Добавить") { _, _ ->
                val lg = l.text.toString().trim()
                val ps = p.text.toString()
                if (lg.length < 3 || ps.length < 8) toast("Логин от 3 символов, пароль от 8")
                else task("Добавление разработчика") { addDev(lg, ps) }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun log(s: String) = ui {
        val color = when {
            s.startsWith("✔") -> 0xFF6EE7A0.toInt()
            s.startsWith("✖") -> 0xFFFF6B8A.toInt()
            s.startsWith("⚠") -> 0xFFFFB86B.toInt()
            else -> 0xFFC9B8FF.toInt()
        }
        val t = TextView(this).apply {
            text = s
            textSize = 13f
            setTextColor(color)
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(0, dp(2), 0, dp(2))
            alpha = 0f
        }
        logBox.addView(t)
        t.animate().alpha(1f).setDuration(250).start()
        if (logBox.childCount > 80) logBox.removeViewAt(0)
    }

    private fun setProgress(done: Long, total: Long) {
        if (total <= 0) return
        ui { bar.progress = (done * 100 / total).toInt().coerceIn(0, 100) }
    }

    private fun task(name: String, block: () -> Unit) {
        if (working) {
            toast("Подожди, предыдущая операция ещё идёт")
            return
        }
        working = true
        ui { logBox.removeAllViews(); bar.progress = 0 }
        log("▶ $name")
        Thread {
            try {
                block()
            } catch (e: Exception) {
                log("✖ Ошибка: ${e.message}")
            } finally {
                working = false
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        when (requestCode) {
            REQ_TREE -> {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (e: Exception) {
                }
                prefs.edit().putString("tree", uri.toString()).apply()
                treeLabel.text = "Папка выбрана: " + (DocumentFile.fromTreeUri(this, uri)?.name ?: "")
            }
            REQ_APK -> {
                prefs.edit().putString("activity", activityField.text.toString().trim()).apply()
                task("Загрузка APK") { publishApk(uri) }
            }
        }
    }

    // ---------- GitHub API ----------

    private fun api(method: String, url: String, body: String? = null): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        c.connectTimeout = 20000
        c.readTimeout = 60000
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray()) }
            }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private val repoApi get() = "https://api.github.com/repos/$OWNER/$REPO"

    private fun getManifest(): Pair<JSONObject, String?> {
        val (code, text) = api("GET", "$repoApi/contents/manifest.json?ref=$BRANCH")
        if (code == 404) return JSONObject().put("version", 0) to null
        if (code != 200) throw Exception("Манифест: HTTP $code (проверь токен)")
        val j = JSONObject(text)
        val raw = String(Base64.decode(j.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
        return JSONObject(raw) to j.getString("sha")
    }

    private fun putManifest(m: JSONObject, sha: String?) {
        val body = JSONObject()
            .put("message", "update manifest v${m.optInt("version")}")
            .put("content", Base64.encodeToString(m.toString(2).toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
            .put("branch", BRANCH)
        if (sha != null) body.put("sha", sha)
        val (code, text) = api("PUT", "$repoApi/contents/manifest.json", body.toString())
        if (code != 200 && code != 201) throw Exception("Не удалось сохранить манифест: HTTP $code $text")
    }

    private fun ensureRelease(tag: String): Long {
        val (code, text) = api("GET", "$repoApi/releases/tags/$tag")
        if (code == 200) return JSONObject(text).getLong("id")
        val body = JSONObject().put("tag_name", tag).put("name", tag)
            .put("target_commitish", BRANCH).put("body", "auto")
        val (c2, t2) = api("POST", "$repoApi/releases", body.toString())
        if (c2 != 201) throw Exception("Не удалось создать релиз $tag: HTTP $c2 $t2")
        return JSONObject(t2).getLong("id")
    }

    private fun listAssets(releaseId: Long): MutableMap<String, Long> {
        val map = HashMap<String, Long>()
        var page = 1
        while (true) {
            val (code, text) = api("GET", "$repoApi/releases/$releaseId/assets?per_page=100&page=$page")
            if (code != 200) throw Exception("Список файлов релиза: HTTP $code")
            val arr = JSONArray(text)
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                map[o.getString("name")] = o.getLong("id")
            }
            page++
        }
        return map
    }

    private fun assetInfo(releaseId: Long, name: String): JSONObject? {
        var page = 1
        while (true) {
            val (code, text) = api("GET", "$repoApi/releases/$releaseId/assets?per_page=100&page=$page")
            if (code != 200) return null
            val arr = JSONArray(text)
            if (arr.length() == 0) return null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.getString("name") == name) return o
            }
            page++
        }
    }

    private fun deleteAsset(id: Long) {
        val (code, _) = api("DELETE", "$repoApi/releases/assets/$id")
        if (code != 204 && code != 404) throw Exception("Не удалось удалить файл релиза: HTTP $code")
    }

    private fun uploadAsset(releaseId: Long, name: String, size: Long, open: () -> InputStream?, onBytes: (Long) -> Unit) {
        if (size > MAX_ASSET) throw Exception("$name больше 2 ГБ, GitHub не примет")
        val url = "https://uploads.github.com/repos/$OWNER/$REPO/releases/$releaseId/assets?name=" +
            URLEncoder.encode(name, "UTF-8")
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Authorization", "Bearer $token")
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("Content-Type", "application/octet-stream")
        c.connectTimeout = 20000
        c.readTimeout = 900000
        c.doOutput = true
        c.setFixedLengthStreamingMode(size)
        try {
            val input = open() ?: throw Exception("Не удалось прочитать $name")
            input.use { ins ->
                c.outputStream.use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        onBytes(n.toLong())
                    }
                }
            }
            val code = c.responseCode
            if (code != 201) {
                val err = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                throw Exception("Загрузка $name: HTTP $code $err")
            }
        } finally {
            c.disconnect()
        }
    }

    // ---------- операции ----------

    private fun sha256(open: () -> InputStream?, onBytes: (Long) -> Unit = {}): String {
        val md = MessageDigest.getInstance("SHA-256")
        val input = open() ?: throw Exception("Не удалось прочитать файл")
        input.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
                onBytes(n.toLong())
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun assetName(path: String): String {
        val h = MessageDigest.getInstance("SHA-1").digest(path.toByteArray())
            .joinToString("") { "%02x".format(it) }.take(8)
        val base = path.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
        return "${h}_$base"
    }

    private fun walk(dir: DocumentFile, prefix: String, out: MutableList<Pair<String, DocumentFile>>) {
        for (f in dir.listFiles()) {
            val n = f.name ?: continue
            if (f.isDirectory) walk(f, "$prefix$n/", out) else out.add((prefix + n) to f)
        }
    }

    private fun publishCache() {
        if (role != Role.OWNER) throw Exception("Нет прав: кеш обновляет только владелец")
        val treeStr = prefs.getString("tree", null) ?: throw Exception("Сначала выбери папку с кешем")
        val root = DocumentFile.fromTreeUri(this, Uri.parse(treeStr))
            ?: throw Exception("Папка недоступна, выбери её заново")

        log("Читаю манифест…")
        val (m, msha) = getManifest()
        val oldFiles = HashMap<String, JSONObject>()
        val oldArr = m.optJSONObject("cache")?.optJSONArray("files")
        if (oldArr != null) for (i in 0 until oldArr.length()) {
            val o = oldArr.getJSONObject(i)
            oldFiles[o.getString("path")] = o
        }

        log("Сканирую папку…")
        val files = ArrayList<Pair<String, DocumentFile>>()
        walk(root, "", files)
        files.removeAll { it.second.length() == 0L }
        if (files.isEmpty()) throw Exception("В папке нет файлов")

        val totalBytes = files.sumOf { it.second.length() }
        var hashed = 0L
        val shas = HashMap<String, String>()
        for ((path, f) in files) {
            log("Хэш: $path")
            shas[path] = sha256({ contentResolver.openInputStream(f.uri) }) { n ->
                hashed += n
                setProgress(hashed, totalBytes)
            }
        }

        val changed = files.filter { (p, _) -> oldFiles[p]?.optString("sha256") != shas[p] }
        val currentPaths = files.map { it.first }.toSet()
        val removed = oldFiles.keys.filter { it !in currentPaths }

        if (changed.isEmpty() && removed.isEmpty()) {
            log("Изменений нет, публиковать нечего.")
            return
        }
        log("Изменено: ${changed.size}, удалено: ${removed.size}")

        val releaseId = ensureRelease("cache")
        val assets = listAssets(releaseId)

        val upTotal = changed.sumOf { it.second.length() }
        var uploaded = 0L
        ui { bar.progress = 0 }
        for ((path, f) in changed) {
            val name = assetName(path)
            assets[name]?.let { deleteAsset(it) }
            log("Загружаю: $path")
            uploadAsset(releaseId, name, f.length(), { contentResolver.openInputStream(f.uri) }) { n ->
                uploaded += n
                setProgress(uploaded, upTotal)
            }
        }
        for (path in removed) {
            val name = oldFiles[path]?.optString("asset").orEmpty().ifEmpty { assetName(path) }
            assets[name]?.let { deleteAsset(it) }
        }

        val arr = JSONArray()
        for ((path, f) in files) {
            val name = assetName(path)
            arr.put(
                JSONObject()
                    .put("path", path)
                    .put("sha256", shas[path])
                    .put("size", f.length())
                    .put("asset", name)
                    .put("url", "https://github.com/$OWNER/$REPO/releases/download/cache/$name")
            )
        }
        val cache = m.optJSONObject("cache") ?: JSONObject()
        cache.put("files", arr)
        m.put("cache", cache)
        m.put("version", m.optInt("version") + 1)
        putManifest(m, msha)
        log("✔ Готово. Версия ${m.optInt("version")}, обновлено файлов: ${changed.size}")
    }

    private fun publishApk(uri: Uri) {
        val tmp = File(cacheDir, "new_client.apk")
        log("Копирую APK…")
        val md = MessageDigest.getInstance("SHA-256")
        var total = 0L
        val input = contentResolver.openInputStream(uri) ?: throw Exception("Не удалось открыть файл")
        input.use { ins ->
            tmp.outputStream().use { out ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    md.update(buf, 0, n)
                    total += n
                }
            }
        }
        val size = total
        val sha = md.digest().joinToString("") { "%02x".format(it) }

        val info = packageManager.getPackageArchiveInfo(tmp.path, 0)
            ?: throw Exception("Это не APK")
        if (info.packageName != GAME_PACKAGE) {
            throw Exception("Пакет ${info.packageName}, а нужен $GAME_PACKAGE")
        }
        val code = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
        log("APK: версия ${info.versionName} (код $code), ${size / 1048576} МБ")

        val (m, msha) = getManifest()
        val oldCode = m.optJSONObject("client")?.optLong("version_code", 0L) ?: 0L
        if (code <= oldCode) {
            log("⚠ Внимание: versionCode $code не выше текущего $oldCode — у игроков обновление не сработает. Подними versionCode в APK.")
        }

        val releaseId = ensureRelease("client")
        listAssets(releaseId)["client.apk"]?.let { deleteAsset(it) }
        log("Загружаю на GitHub…")
        var up = 0L
        try {
            uploadAsset(releaseId, "client.apk", size, { tmp.inputStream() }) { n ->
                up += n
                setProgress(up, size)
            }
        } catch (e: java.net.SocketTimeoutException) {
            log("GitHub долго отвечает, проверяю, дошёл ли файл…")
            var ok = false
            for (i in 1..9) {
                Thread.sleep(10_000)
                val a = assetInfo(releaseId, "client.apk")
                if (a != null && a.optString("state") == "uploaded" && a.optLong("size") == size) {
                    ok = true
                    break
                }
            }
            if (!ok) throw Exception("Таймаут, файл не загрузился. Попробуй ещё раз, лучше на стабильном Wi-Fi.")
            log("Файл на GitHub, продолжаю.")
        }

        val client = JSONObject()
            .put("version_code", code)
            .put("version_name", info.versionName ?: "")
            .put("url", "https://github.com/$OWNER/$REPO/releases/download/client/client.apk")
            .put("sha256", sha)
            .put("size", size)
            .put("activity", prefs.getString("activity", "") ?: "")
        m.put("client", client)
        m.put("version", m.optInt("version") + 1)
        putManifest(m, msha)
        tmp.delete()
        log("✔ Готово. Клиент обновлён, версия манифеста ${m.optInt("version")}")
    }

    private fun saveActivity() {
        val act = activityField.text.toString().trim()
        prefs.edit().putString("activity", act).apply()
        val (m, msha) = getManifest()
        val client = m.optJSONObject("client") ?: JSONObject()
        client.put("activity", act)
        m.put("client", client)
        putManifest(m, msha)
        log("✔ Activity сохранена: $act")
    }

    private fun sendNotice() {
        val title = noticeTitle.text.toString().trim()
        val text = noticeText.text.toString().trim()
        if (text.isEmpty()) throw Exception("Введи текст уведомления")
        val (m, msha) = getManifest()
        m.put(
            "notice",
            JSONObject().put("id", System.currentTimeMillis() / 1000).put("title", title).put("text", text)
        )
        putManifest(m, msha)
        log("✔ Уведомление отправлено. Игроки увидят его при ближайшей проверке (до нескольких минут).")
    }

    private fun loadInfo() {
        val (m, _) = getManifest()
        val info = m.optJSONObject("info") ?: return
        ui {
            forumField.setText(info.optString("forum_url"))
            aboutField.setText(info.optString("about_url"))
            updTitleField.setText(info.optString("updates_title"))
            updTextField.setText(info.optString("updates_text"))
        }
    }

    private fun saveInfo() {
        val forum = forumField.text.toString().trim()
        val about = aboutField.text.toString().trim()
        for (u in listOf(forum, about)) {
            if (u.isNotEmpty() && !u.startsWith("https://") && !u.startsWith("http://")) {
                throw Exception("Ссылка должна начинаться с https://")
            }
        }
        val (m, msha) = getManifest()
        m.put(
            "info",
            JSONObject()
                .put("forum_url", forum)
                .put("about_url", about)
                .put("updates_title", updTitleField.text.toString().trim())
                .put("updates_text", updTextField.text.toString().trim())
        )
        m.put("version", m.optInt("version") + 1)
        putManifest(m, msha)
        log("✔ Оформление сохранено. Игроки увидят его при следующей проверке.")
    }

    // ---------- разработчики ----------

    private fun deriveKey(pass: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        val k = f.generateSecret(PBEKeySpec(pass.toCharArray(), salt, 120_000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }

    private fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    private fun encryptToken(pass: String, tok: String): JSONObject {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, deriveKey(pass, salt), GCMParameterSpec(128, iv))
        val ct = c.doFinal(tok.toByteArray(Charsets.UTF_8))
        return JSONObject().put("salt", b64(salt)).put("iv", b64(iv)).put("ct", b64(ct))
    }

    private fun decryptToken(pass: String, e: JSONObject): String? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(
            Cipher.DECRYPT_MODE,
            deriveKey(pass, unb64(e.getString("salt"))),
            GCMParameterSpec(128, unb64(e.getString("iv")))
        )
        String(c.doFinal(unb64(e.getString("ct"))), Charsets.UTF_8)
    } catch (ex: Exception) {
        null
    }

    /** Список разработчиков без токена: файл публичный, пароль разработчика расшифровывает токен. */
    private fun fetchDevs(): JSONObject {
        val c = URL("$repoApi/contents/config/devs.json?ref=$BRANCH").openConnection() as HttpURLConnection
        c.setRequestProperty("Accept", "application/vnd.github.raw+json")
        c.connectTimeout = 15000
        c.readTimeout = 20000
        try {
            val code = c.responseCode
            if (code == 404) return JSONObject().put("devs", JSONArray())
            if (code != 200) throw Exception("HTTP $code")
            return JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        } finally {
            c.disconnect()
        }
    }

    private fun getDevsFile(): Pair<JSONObject, String?> {
        val (code, text) = api("GET", "$repoApi/contents/config/devs.json?ref=$BRANCH")
        if (code == 404) return JSONObject().put("devs", JSONArray()) to null
        if (code != 200) throw Exception("devs.json: HTTP $code")
        val j = JSONObject(text)
        val raw = String(Base64.decode(j.getString("content"), Base64.DEFAULT), Charsets.UTF_8)
        return JSONObject(raw) to j.getString("sha")
    }

    private fun putDevsFile(o: JSONObject, sha: String?) {
        val body = JSONObject()
            .put("message", "update devs")
            .put("content", Base64.encodeToString(o.toString(2).toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
            .put("branch", BRANCH)
        if (sha != null) body.put("sha", sha)
        val (code, text) = api("PUT", "$repoApi/contents/config/devs.json", body.toString())
        if (code != 200 && code != 201) throw Exception("Не удалось сохранить список: HTTP $code $text")
    }

    private fun addDev(login: String, pass: String) {
        if (role != Role.OWNER) throw Exception("Нет прав")
        if (login.equals(prefs.getString("login", ""), true)) throw Exception("Этот логин занят владельцем")
        log("Шифрую доступ…")
        val entry = encryptToken(pass, token).put("login", login)
        val (o, sha) = getDevsFile()
        val arr = o.optJSONArray("devs") ?: JSONArray()
        for (i in 0 until arr.length()) {
            if (arr.getJSONObject(i).getString("login").equals(login, true)) {
                throw Exception("Такой разработчик уже есть")
            }
        }
        arr.put(entry)
        o.put("devs", arr)
        putDevsFile(o, sha)
        log("✔ Разработчик $login добавлен. Вход заработает сразу.")
    }

    private fun removeDev(login: String) {
        if (role != Role.OWNER) throw Exception("Нет прав")
        val (o, sha) = getDevsFile()
        val arr = o.optJSONArray("devs") ?: JSONArray()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            if (!e.getString("login").equals(login, true)) out.put(e)
        }
        o.put("devs", out)
        putDevsFile(o, sha)
        log("✔ Разработчик $login удалён.")
    }

    private fun showDevList() {
        val (o, _) = getDevsFile()
        val arr = o.optJSONArray("devs") ?: JSONArray()
        val names = (0 until arr.length()).map { arr.getJSONObject(it).getString("login") }
        log("Разработчиков: ${names.size}")
        ui {
            if (names.isEmpty()) {
                toast("Разработчиков пока нет")
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Нажми, чтобы удалить")
                    .setItems(names.toTypedArray()) { _, which ->
                        task("Удаление ${names[which]}") { removeDev(names[which]) }
                    }
                    .setNegativeButton("Закрыть", null)
                    .show()
            }
        }
    }
}
