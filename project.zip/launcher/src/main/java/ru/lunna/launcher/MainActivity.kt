package ru.lunna.launcher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class MainActivity : Activity() {

    companion object {
        const val MANIFEST_URL =
            "https://raw.githubusercontent.com/az3005484-afk/lunna-launcher/main/manifest.json"
        const val GAME_PACKAGE = "com.kranin"
        val CACHE_DIR = File(Environment.getExternalStorageDirectory(), "LunnaRussia")
        const val VIOLET = 0xFF7B2CFF.toInt()
        const val BG = 0xFF0B0614.toInt()
    }

    private enum class Mode { ACCESS, UPDATE, PLAY, RETRY, BUSY }

    private data class Entry(val path: String, val sha: String, val size: Long, val url: String)

    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var button: Button

    private var mode = Mode.BUSY
    private var manifest: JSONObject? = null

    @Volatile
    private var busy = false

    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            if (!busy && mode != Mode.BUSY) refresh()
            handler.postDelayed(this, 180_000)
        }
    }

    private val prefs by lazy { getSharedPreferences("state", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(block: () -> Unit) = runOnUiThread { block() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(BG)
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
            adjustViewBounds = true
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(220), dp(220)))

        val title = TextView(this).apply {
            text = "LUNNA RUSSIA"
            setTextColor(Color.WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(8))
        }
        root.addView(title)

        status = TextView(this).apply {
            setTextColor(0xFFC9B8FF.toInt())
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(16))
        }
        root.addView(status)

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(VIOLET)
        }
        root.addView(bar, LinearLayout.LayoutParams(dp(320), dp(8)))

        button = Button(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            isAllCaps = false
            background = GradientDrawable().apply {
                setColor(VIOLET)
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener { onButton() }
        }
        val lp = LinearLayout.LayoutParams(dp(320), dp(56))
        lp.topMargin = dp(24)
        root.addView(button, lp)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(poll)
        refresh()
        handler.postDelayed(poll, 180_000)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
    }

    private fun setMode(m: Mode, text: String) {
        ui {
            mode = m
            status.text = text
            button.isEnabled = m != Mode.BUSY
            button.alpha = if (m == Mode.BUSY) 0.5f else 1f
            button.text = when (m) {
                Mode.ACCESS -> "Дать доступ"
                Mode.UPDATE -> "Обновить"
                Mode.PLAY -> "Играть"
                Mode.RETRY -> "Повторить"
                Mode.BUSY -> "Подождите…"
            }
            if (m != Mode.BUSY) bar.progress = if (m == Mode.PLAY) 100 else 0
        }
    }

    private fun onButton() {
        when (mode) {
            Mode.ACCESS -> requestStorage()
            Mode.UPDATE -> runUpdate()
            Mode.PLAY -> play()
            Mode.RETRY -> refresh()
            Mode.BUSY -> {}
        }
    }

    // ---------- доступ к файлам ----------

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), 1
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
    }

    // ---------- проверка обновлений ----------

    private fun refresh() {
        if (busy) return
        if (!hasStorage()) {
            setMode(Mode.ACCESS, "Нужен доступ к файлам, чтобы сохранить кеш игры")
            return
        }
        busy = true
        setMode(Mode.BUSY, "Проверяем обновления…")
        Thread {
            try {
                val m = JSONObject(httpGet(MANIFEST_URL + "?t=" + System.currentTimeMillis()))
                manifest = m
                ui { showNotice(m.optJSONObject("notice")) }
                val pending = pendingFiles(m)
                val needClient = clientNeeded(m)
                if (needClient || pending.isNotEmpty()) {
                    val mb = pending.sumOf { it.size } / 1048576
                    val what = if (needClient) "игра + кеш" else "кеш"
                    setMode(Mode.UPDATE, "Доступно обновление ($what, ~$mb МБ)")
                } else {
                    setMode(Mode.PLAY, "Всё актуально")
                }
            } catch (e: Exception) {
                setMode(Mode.RETRY, "Нет связи с сервером")
            } finally {
                busy = false
            }
        }.start()
    }

    private fun showNotice(n: JSONObject?) {
        if (n == null || isFinishing) return
        val id = n.optLong("id", 0)
        val text = n.optString("text")
        if (id <= prefs.getLong("notice_id", 0) || text.isEmpty()) return
        prefs.edit().putLong("notice_id", id).apply()
        val title = n.optString("title").ifEmpty { "Lunna Russia" }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun pendingFiles(m: JSONObject): List<Entry> {
        val arr = m.optJSONObject("cache")?.optJSONArray("files") ?: return emptyList()
        val out = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val path = o.getString("path")
            if (path.contains("..")) continue
            val e = Entry(path, o.getString("sha256"), o.optLong("size"), o.getString("url"))
            val f = File(CACHE_DIR, path)
            val ok = f.isFile && f.length() == e.size && prefs.getString("f:$path", "") == e.sha
            if (!ok) out.add(e)
        }
        return out
    }

    private fun installedCode(): Long = try {
        val pi = packageManager.getPackageInfo(GAME_PACKAGE, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    } catch (e: PackageManager.NameNotFoundException) {
        -1L
    }

    private fun clientNeeded(m: JSONObject): Boolean {
        val c = m.optJSONObject("client") ?: return false
        if (c.optString("url").isEmpty()) return false
        return installedCode() < c.optLong("version_code")
    }

    // ---------- обновление ----------

    private fun runUpdate() {
        val m = manifest ?: return
        if (busy) return
        val needClient = clientNeeded(m)
        if (needClient && Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")
                )
            )
            Toast.makeText(this, "Разреши установку и нажми «Обновить» снова", Toast.LENGTH_LONG).show()
            return
        }
        busy = true
        setMode(Mode.BUSY, "Подготовка…")
        Thread {
            var ok = false
            try {
                val pending = pendingFiles(m)
                val client = m.optJSONObject("client")
                val total = pending.sumOf { it.size } +
                    (if (needClient && client != null) client.optLong("size") else 0L)
                var done = 0L

                for (e in pending) {
                    val dest = File(CACHE_DIR, e.path)
                    val sha = download(e.url, dest) { n ->
                        done += n
                        progress(done, total, e.path)
                    }
                    if (!sha.equals(e.sha, true)) {
                        dest.delete()
                        throw Exception("Файл повреждён: ${e.path}")
                    }
                    prefs.edit().putString("f:${e.path}", e.sha).apply()
                }
                cleanup(m)

                if (needClient && client != null) {
                    val apk = File(cacheDir, "client.apk")
                    val sha = download(client.getString("url"), apk) { n ->
                        done += n
                        progress(done, total, "Игра")
                    }
                    if (!sha.equals(client.optString("sha256"), true)) {
                        apk.delete()
                        throw Exception("APK игры повреждён")
                    }
                    busy = false
                    setMode(Mode.RETRY, "Установи игру и вернись в лаунчер")
                    ui { installApk(apk) }
                } else {
                    ok = true
                }
            } catch (e: Exception) {
                busy = false
                setMode(Mode.RETRY, "Ошибка: ${e.message}")
            }
            if (ok) {
                busy = false
                ui { refresh() }
            }
        }.start()
    }

    private fun cleanup(m: JSONObject) {
        val arr = m.optJSONObject("cache")?.optJSONArray("files") ?: return
        val names = HashSet<String>()
        for (i in 0 until arr.length()) names.add(arr.getJSONObject(i).getString("path"))
        for (k in prefs.all.keys.toList()) {
            if (k.startsWith("f:") && k.substring(2) !in names) {
                File(CACHE_DIR, k.substring(2)).delete()
                prefs.edit().remove(k).apply()
            }
        }
    }

    private fun progress(done: Long, total: Long, name: String) {
        if (total <= 0) return
        ui {
            bar.progress = (done * 100 / total).toInt().coerceIn(0, 100)
            status.text = "Загрузка: ${done / 1048576} / ${total / 1048576} МБ\n$name"
        }
    }

    private fun installApk(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun play() {
        val act = manifest?.optJSONObject("client")?.optString("activity").orEmpty()
        val intent = if (act.isNotEmpty()) {
            Intent(Intent.ACTION_MAIN).setClassName(GAME_PACKAGE, act)
        } else {
            packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
        }
        if (intent == null) {
            Toast.makeText(this, "Не удалось запустить игру", Toast.LENGTH_LONG).show()
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить игру: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- сеть ----------

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Cache-Control", "no-cache")
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает файл, возвращает sha256. onBytes получает размер каждого прочитанного куска. */
    private fun download(url: String, dest: File, onBytes: (Long) -> Unit): String {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            val md = MessageDigest.getInstance("SHA-256")
            c.inputStream.use { input ->
                part.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                        onBytes(n.toLong())
                    }
                }
            }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw Exception("Не удалось сохранить файл")
            return md.digest().joinToString("") { "%02x".format(it) }
        } finally {
            c.disconnect()
            if (part.exists()) part.delete()
        }
    }
}
