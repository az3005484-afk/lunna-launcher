package ru.lunna.launcher

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class MainActivity : Activity() {

    companion object {
        const val MANIFEST_URL =
            "https://raw.githubusercontent.com/az3005484-afk/lunna-launcher/main/manifest.json"
        const val GAME_PACKAGE = "com.mobile.project5875"
        const val DEFAULT_ACTIVITY = "com.blackhub.bronline.launcher.activities.MainActivity"
        val CACHE_DIR = File(Environment.getExternalStorageDirectory(), "LunnaRussia")
        const val VIOLET = 0xFF7B2CFF.toInt()
        const val BG = 0xFF0B0614.toInt()
        const val BIG_FILE = 8L * 1024 * 1024
        const val SEGMENTS = 6
        const val VIOLET_LIGHT = 0xFFB89CFF.toInt()
    }

    private enum class Mode { ACCESS, UPDATE, PLAY, RETRY, BUSY }

    private data class Entry(val path: String, val sha: String, val size: Long, val url: String)

    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var button: Button
    private lateinit var btnWrap: FrameLayout
    private var pulser: ObjectAnimator? = null
    private var barAnim: ObjectAnimator? = null
    private lateinit var forumBtn: Button
    private lateinit var aboutBtn: Button
    private lateinit var linksRow: LinearLayout
    private lateinit var updTitle: TextView
    private lateinit var updText: TextView
    private var forumUrl = ""
    private var aboutUrl = ""

    private var mode = Mode.BUSY
    private var manifest: JSONObject? = null

    @Volatile
    private var busy = false

    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            if (!busy && mode != Mode.BUSY) refresh()
            handler.postDelayed(this, 180_000)
        }
    }

    private val prefs by lazy { getSharedPreferences("state", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun ui(block: () -> Unit) = runOnUiThread { block() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke > 0) setStroke(dp(stroke), strokeColor)
        }

    private fun linkButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 15f
        background = rounded(0x331B1130, 14, 2, VIOLET)
        pressable()
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        val screenW = resources.displayMetrics.widthPixels
        val w = minOf(dp(560), screenW - dp(32))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(28), dp(16), dp(20))
        }

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.wordmark)
            adjustViewBounds = true
        }
        root.addView(logo, LinearLayout.LayoutParams(minOf(w, dp(340)), LinearLayout.LayoutParams.WRAP_CONTENT))
        logo.enter(0, 0f)
        logo.postDelayed({ logo.floatLoop(dp(5).toFloat()) }, 800)

        // карточка «Последние обновления»
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xCC1B1130.toInt(), 18, 2, 0xFF3A2370.toInt())
            setPadding(dp(18), dp(14), dp(18), dp(16))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val pill = TextView(this).apply {
            text = "NEW"
            setTextColor(Color.WHITE)
            textSize = 10f
            setPadding(dp(8), dp(2), dp(8), dp(2))
            background = rounded(VIOLET, 8)
        }
        ObjectAnimator.ofFloat(pill, View.ALPHA, 1f, 0.55f).apply {
            duration = 900
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
        head.addView(pill)
        head.addView(TextView(this).apply {
            text = "ПОСЛЕДНИЕ ОБНОВЛЕНИЯ"
            setTextColor(VIOLET_LIGHT)
            textSize = 12f
            letterSpacing = 0.12f
            setPadding(dp(10), 0, 0, 0)
        })
        card.addView(head)
        updTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(0, dp(8), 0, dp(4))
        }
        card.addView(updTitle)
        updText = TextView(this).apply {
            setTextColor(0xFFD9CCFF.toInt())
            textSize = 14f
            setLineSpacing(0f, 1.15f)
        }
        card.addView(updText)
        val cardLp = LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT)
        cardLp.topMargin = dp(14)
        root.addView(card, cardLp)
        card.enter(200)

        // кнопки «Форум» и «О нас»
        linksRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        forumBtn = linkButton("💬  Форум") { openUrl(forumUrl) }
        aboutBtn = linkButton("✈️  О нас") { openUrl(aboutUrl) }
        val half = LinearLayout.LayoutParams(0, dp(50), 1f)
        half.rightMargin = dp(6)
        val half2 = LinearLayout.LayoutParams(0, dp(50), 1f)
        half2.leftMargin = dp(6)
        linksRow.addView(forumBtn, half)
        linksRow.addView(aboutBtn, half2)
        val rowLp = LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT)
        rowLp.topMargin = dp(14)
        root.addView(linksRow, rowLp)
        linksRow.enter(330)

        status = TextView(this).apply {
            setTextColor(0xFFC9B8FF.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(8))
        }
        root.addView(status, LinearLayout.LayoutParams(w, LinearLayout.LayoutParams.WRAP_CONTENT))

        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = ColorStateList.valueOf(VIOLET)
        }
        root.addView(bar, LinearLayout.LayoutParams(w, dp(8)))
        bar.enter(450, 0f)

        button = Button(this).apply {
            setTextColor(Color.WHITE)
            textSize = 20f
            isAllCaps = false
            pressable()
            setOnClickListener { onButton() }
        }
        styleButton(Mode.BUSY)
        btnWrap = FrameLayout(this).also {
            it.addView(button, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        val lp = LinearLayout.LayoutParams(w, dp(62))
        lp.topMargin = dp(16)
        root.addView(btnWrap, lp)
        btnWrap.enter(560)

        val ver = TextView(this).apply {
            val v = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""
            text = "Lunna Russia Launcher v$v"
            setTextColor(0x66FFFFFF)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        }
        root.addView(ver)
        ver.enter(700, 0f)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        }
        val frame = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF22103F.toInt(), BG)
            )
            addView(ParticleView(context))
            addView(scroll)
        }
        setContentView(frame)

        applyInfo(prefs.getString("info", null)?.let { runCatching { JSONObject(it) }.getOrNull() })
    }

    private fun styleButton(m: Mode) {
        val (c1, c2) = when (m) {
            Mode.PLAY -> 0xFF7B2CFF.toInt() to 0xFFD04CFF.toInt()
            Mode.UPDATE -> 0xFF2C7BFF.toInt() to 0xFF7B2CFF.toInt()
            Mode.ACCESS, Mode.RETRY -> 0xFFFF7A2C.toInt() to 0xFFFF2C7B.toInt()
            Mode.BUSY -> 0xFF4A3A70.toInt() to 0xFF3A2370.toInt()
        }
        button.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2)
        ).apply { cornerRadius = dp(16).toFloat() }
    }

    private fun fadeStatus(t: String) {
        if (status.text.toString() == t) return
        status.animate().cancel()
        status.animate().alpha(0f).setDuration(120).withEndAction {
            status.text = t
            status.animate().alpha(1f).setDuration(220).start()
        }.start()
    }

    private fun setBar(v: Int) {
        barAnim?.cancel()
        barAnim = ObjectAnimator.ofInt(bar, "progress", bar.progress, v).apply {
            duration = 250
            start()
        }
    }

    private fun applyInfo(info: JSONObject?) {
        forumUrl = info?.optString("forum_url").orEmpty()
        aboutUrl = info?.optString("about_url").orEmpty()
        forumBtn.visibility = if (forumUrl.isEmpty()) View.GONE else View.VISIBLE
        aboutBtn.visibility = if (aboutUrl.isEmpty()) View.GONE else View.VISIBLE
        linksRow.visibility =
            if (forumUrl.isEmpty() && aboutUrl.isEmpty()) View.GONE else View.VISIBLE
        val t = info?.optString("updates_title").orEmpty()
        val x = info?.optString("updates_text").orEmpty()
        updTitle.text = t
        updTitle.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
        updText.text = if (x.isEmpty() && t.isEmpty()) "Скоро здесь появятся новости проекта" else x
    }

    private fun openUrl(url: String) {
        if (url.isEmpty()) return
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось открыть ссылку", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(poll)
        refresh()
        handler.postDelayed(poll, 180_000)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
    }

    private fun setMode(m: Mode, text: String) {
        ui {
            mode = m
            fadeStatus(text)
            button.isEnabled = m != Mode.BUSY
            button.alpha = if (m == Mode.BUSY) 0.6f else 1f
            button.text = when (m) {
                Mode.ACCESS -> "Дать доступ"
                Mode.UPDATE -> "Обновить"
                Mode.PLAY -> "Играть"
                Mode.RETRY -> "Повторить"
                Mode.BUSY -> "Подождите…"
            }
            styleButton(m)
            if (m != Mode.BUSY) setBar(if (m == Mode.PLAY) 100 else 0)
            pulser?.cancel()
            btnWrap.scaleX = 1f
            btnWrap.scaleY = 1f
            if (m == Mode.PLAY || m == Mode.UPDATE) pulser = btnWrap.pulse()
        }
    }

    private fun onButton() {
        when (mode) {
            Mode.ACCESS -> requestStorage()
            Mode.UPDATE -> runUpdate()
            Mode.PLAY -> play()
            Mode.RETRY -> refresh()
            Mode.BUSY -> {}
        }
    }

    // ---------- доступ к файлам ----------

    private fun hasStorage(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), 1
            )
        }
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
    }

    // ---------- проверка обновлений ----------

    private fun refresh() {
        if (busy) return
        if (!hasStorage()) {
            setMode(Mode.ACCESS, "Нужен доступ к файлам, чтобы сохранить кеш игры")
            return
        }
        busy = true
        setMode(Mode.BUSY, "Проверяем обновления…")
        Thread {
            try {
                val m = JSONObject(httpGet(MANIFEST_URL + "?t=" + System.currentTimeMillis()))
                manifest = m
                ui {
                    val info = m.optJSONObject("info")
                    if (info != null) prefs.edit().putString("info", info.toString()).apply()
                    applyInfo(info)
                    showNotice(m.optJSONObject("notice"))
                }
                val pending = pendingFiles(m)
                val needClient = clientNeeded(m)
                if (needClient || pending.isNotEmpty()) {
                    val mb = pending.sumOf { it.size } / 1048576
                    val what = if (needClient) "игра + кеш" else "кеш"
                    setMode(Mode.UPDATE, "Доступно обновление ($what, ~$mb МБ)")
                } else {
                    setMode(Mode.PLAY, "Всё актуально")
                }
            } catch (e: Exception) {
                setMode(Mode.RETRY, "Нет связи с сервером")
            } finally {
                busy = false
            }
        }.start()
    }

    private fun showNotice(n: JSONObject?) {
        if (n == null || isFinishing) return
        val id = n.optLong("id", 0)
        val text = n.optString("text")
        if (id <= prefs.getLong("notice_id", 0) || text.isEmpty()) return
        prefs.edit().putLong("notice_id", id).apply()
        val title = n.optString("title").ifEmpty { "Lunna Russia" }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun pendingFiles(m: JSONObject): List<Entry> {
        val arr = m.optJSONObject("cache")?.optJSONArray("files") ?: return emptyList()
        val out = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val path = o.getString("path")
            if (path.contains("..")) continue
            val e = Entry(path, o.getString("sha256"), o.optLong("size"), o.getString("url"))
            val f = File(CACHE_DIR, path)
            val ok = f.isFile && f.length() == e.size && prefs.getString("f:$path", "") == e.sha
            if (!ok) out.add(e)
        }
        return out
    }

    private fun installedCode(): Long = try {
        val pi = packageManager.getPackageInfo(GAME_PACKAGE, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
    } catch (e: PackageManager.NameNotFoundException) {
        -1L
    }

    private fun clientNeeded(m: JSONObject): Boolean {
        val c = m.optJSONObject("client") ?: return false
        if (c.optString("url").isEmpty()) return false
        return installedCode() < c.optLong("version_code")
    }

    // ---------- обновление ----------

    private fun runUpdate() {
        val m = manifest ?: return
        if (busy) return
        val needClient = clientNeeded(m)
        if (needClient && Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")
                )
            )
            Toast.makeText(this, "Разреши установку и нажми «Обновить» снова", Toast.LENGTH_LONG).show()
            return
        }
        busy = true
        setMode(Mode.BUSY, "Подготовка…")
        Thread {
            var ok = false
            try {
                val pending = pendingFiles(m)
                val client = m.optJSONObject("client")
                val total = pending.sumOf { it.size } +
                    (if (needClient && client != null) client.optLong("size") else 0L)
                val done = java.util.concurrent.atomic.AtomicLong(0L)
                val report: (Long, String) -> Unit = { n, name ->
                    progress(done.addAndGet(n), total, name)
                }

                fun fetch(e: Entry) {
                    val dest = File(CACHE_DIR, e.path)
                    val sha = downloadFast(e.url, dest, e.size) { n -> report(n, e.path) }
                    if (!sha.equals(e.sha, true)) {
                        dest.delete()
                        throw Exception("Файл повреждён: ${e.path}")
                    }
                    prefs.edit().putString("f:${e.path}", e.sha).apply()
                }

                // мелкие файлы качаем по 4 штуки одновременно, крупные по очереди в несколько потоков
                val (big, small) = pending.partition { it.size >= BIG_FILE }
                val pool = java.util.concurrent.Executors.newFixedThreadPool(4)
                try {
                    val futures = small.map { e ->
                        pool.submit(java.util.concurrent.Callable { fetch(e) })
                    }
                    for (f in futures) {
                        try {
                            f.get()
                        } catch (ex: java.util.concurrent.ExecutionException) {
                            throw (ex.cause as? Exception) ?: ex
                        }
                    }
                } finally {
                    pool.shutdownNow()
                }
                for (e in big) fetch(e)
                cleanup(m)

                if (needClient && client != null) {
                    val apk = File(cacheDir, "client.apk")
                    val sha = downloadFast(client.getString("url"), apk, client.optLong("size")) { n ->
                        report(n, "Игра")
                    }
                    if (!sha.equals(client.optString("sha256"), true)) {
                        apk.delete()
                        throw Exception("APK игры повреждён")
                    }
                    busy = false
                    setMode(Mode.RETRY, "Установи игру и вернись в лаунчер")
                    ui { installApk(apk) }
                } else {
                    ok = true
                }
            } catch (e: Exception) {
                busy = false
                setMode(Mode.RETRY, "Ошибка: ${e.message}")
            }
            if (ok) {
                busy = false
                ui { refresh() }
            }
        }.start()
    }

    private fun cleanup(m: JSONObject) {
        val arr = m.optJSONObject("cache")?.optJSONArray("files") ?: return
        val names = HashSet<String>()
        for (i in 0 until arr.length()) names.add(arr.getJSONObject(i).getString("path"))
        for (k in prefs.all.keys.toList()) {
            if (k.startsWith("f:") && k.substring(2) !in names) {
                File(CACHE_DIR, k.substring(2)).delete()
                prefs.edit().remove(k).apply()
            }
        }
    }

    private fun progress(done: Long, total: Long, name: String) {
        if (total <= 0) return
        ui {
            bar.progress = (done * 100 / total).toInt().coerceIn(0, 100)
            status.text = "Загрузка: ${done / 1048576} / ${total / 1048576} МБ\n$name"
        }
    }

    private fun installApk(f: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    private fun play() {
        val act = manifest?.optJSONObject("client")?.optString("activity").orEmpty().ifEmpty { DEFAULT_ACTIVITY }
        val intent = if (act.isNotEmpty()) {
            Intent(Intent.ACTION_MAIN).setClassName(GAME_PACKAGE, act)
        } else {
            packageManager.getLaunchIntentForPackage(GAME_PACKAGE)
        }
        if (intent == null) {
            Toast.makeText(this, "Не удалось запустить игру", Toast.LENGTH_LONG).show()
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось запустить игру: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private class NoRangeException : Exception()

    private fun downloadFast(url: String, dest: File, size: Long, onBytes: (Long) -> Unit): String {
        if (size < BIG_FILE) return download(url, dest, onBytes)
        try {
            return downloadSegmented(url, dest, size, onBytes)
        } catch (e: NoRangeException) {
            // сервер не умеет докачку по частям, качаем обычным способом
        }
        return download(url, dest, onBytes)
    }

    private fun downloadSegmented(url: String, dest: File, size: Long, onBytes: (Long) -> Unit): String {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        val error = java.util.concurrent.atomic.AtomicReference<Exception?>(null)
        try {
            java.io.RandomAccessFile(part, "rw").use { raf ->
                raf.setLength(size)
                val ch = raf.channel
                val chunk = (size + SEGMENTS - 1) / SEGMENTS
                val threads = (0 until SEGMENTS).map { i ->
                    val start = i * chunk
                    val end = minOf(size - 1, start + chunk - 1)
                    Thread {
                        try {
                            fetchRange(url, ch, start, end, onBytes, error)
                        } catch (e: Exception) {
                            error.compareAndSet(null, e)
                        }
                    }.also { it.start() }
                }
                threads.forEach { it.join() }
            }
            error.get()?.let { throw it }
            val sha = sha256File(part)
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw Exception("Не удалось сохранить файл")
            return sha
        } catch (e: Exception) {
            part.delete()
            throw e
        }
    }

    private fun fetchRange(
        url: String,
        ch: java.nio.channels.FileChannel,
        start: Long,
        end: Long,
        onBytes: (Long) -> Unit,
        error: java.util.concurrent.atomic.AtomicReference<Exception?>
    ) {
        var pos = start
        var attempts = 0
        while (pos <= end) {
            if (error.get() != null) return
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("Range", "bytes=$pos-$end")
            try {
                if (c.responseCode != 206) throw NoRangeException()
                c.inputStream.use { input ->
                    val buf = ByteArray(256 * 1024)
                    while (pos <= end) {
                        val n = input.read(buf)
                        if (n < 0) break
                        val take = minOf(n.toLong(), end - pos + 1).toInt()
                        val bb = java.nio.ByteBuffer.wrap(buf, 0, take)
                        var p = pos
                        while (bb.hasRemaining()) p += ch.write(bb, p)
                        pos += take
                        onBytes(take.toLong())
                    }
                }
                if (pos <= end) {
                    attempts++
                    if (attempts > 3) throw Exception("Обрыв загрузки")
                }
            } catch (e: NoRangeException) {
                throw e
            } catch (e: Exception) {
                attempts++
                if (attempts > 3) throw e
            } finally {
                c.disconnect()
            }
        }
    }

    private fun sha256File(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { input ->
            val buf = ByteArray(256 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    // ---------- сеть ----------

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("Cache-Control", "no-cache")
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Скачивает файл, возвращает sha256. onBytes получает размер каждого прочитанного куска. */
    private fun download(url: String, dest: File, onBytes: (Long) -> Unit): String {
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = true
        try {
            if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
            val md = MessageDigest.getInstance("SHA-256")
            c.inputStream.use { input ->
                part.outputStream().use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        md.update(buf, 0, n)
                        onBytes(n.toLong())
                    }
                }
            }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) throw Exception("Не удалось сохранить файл")
            return md.digest().joinToString("") { "%02x".format(it) }
        } finally {
            c.disconnect()
            if (part.exists()) part.delete()
        }
    }
}
